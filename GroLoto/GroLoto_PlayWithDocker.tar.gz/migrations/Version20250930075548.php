<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20250930075548 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE messenger_messages (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, body CLOB NOT NULL, headers CLOB NOT NULL, queue_name VARCHAR(190) NOT NULL, created_at DATETIME NOT NULL --(DC2Type:datetime_immutable)
        , available_at DATETIME NOT NULL --(DC2Type:datetime_immutable)
        , delivered_at DATETIME DEFAULT NULL --(DC2Type:datetime_immutable)
        )');
        $this->addSql('CREATE INDEX IDX_75EA56E0FB7336F0 ON messenger_messages (queue_name)');
        $this->addSql('CREATE INDEX IDX_75EA56E0E3BD61CE ON messenger_messages (available_at)');
        $this->addSql('CREATE INDEX IDX_75EA56E016BA31DB ON messenger_messages (delivered_at)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__AFFECTATION_CRENEAU AS SELECT id, id_creneau, id_benevole, id_utilisateur, date_affectation, statut, notes FROM AFFECTATION_CRENEAU');
        $this->addSql('DROP TABLE AFFECTATION_CRENEAU');
        $this->addSql('CREATE TABLE AFFECTATION_CRENEAU (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_creneau INTEGER NOT NULL, id_benevole INTEGER NOT NULL, id_utilisateur INTEGER DEFAULT NULL, date_affectation DATETIME DEFAULT NULL, statut VARCHAR(255) DEFAULT \'assigne\', notes CLOB DEFAULT NULL, FOREIGN KEY (id_creneau) REFERENCES CRENEAU (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE, FOREIGN KEY (id_benevole) REFERENCES BENEVOLE (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE, FOREIGN KEY (id_utilisateur) REFERENCES UTILISATEUR (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO AFFECTATION_CRENEAU (id, id_creneau, id_benevole, id_utilisateur, date_affectation, statut, notes) SELECT id, id_creneau, id_benevole, id_utilisateur, date_affectation, statut, notes FROM __temp__AFFECTATION_CRENEAU');
        $this->addSql('DROP TABLE __temp__AFFECTATION_CRENEAU');
        $this->addSql('CREATE INDEX IDX_E3AC04B627FB222F ON AFFECTATION_CRENEAU (id_creneau)');
        $this->addSql('CREATE INDEX IDX_E3AC04B6E4DAA34E ON AFFECTATION_CRENEAU (id_benevole)');
        $this->addSql('CREATE INDEX IDX_E3AC04B650EAE44 ON AFFECTATION_CRENEAU (id_utilisateur)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__BENEVOLE AS SELECT id, id_utilisateur, adresse, contact_urgence, notes, actif FROM BENEVOLE');
        $this->addSql('DROP TABLE BENEVOLE');
        $this->addSql('CREATE TABLE BENEVOLE (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_utilisateur INTEGER NOT NULL, adresse CLOB DEFAULT NULL, contact_urgence CLOB DEFAULT NULL, notes CLOB DEFAULT NULL, actif BOOLEAN NOT NULL, FOREIGN KEY (id_utilisateur) REFERENCES UTILISATEUR (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO BENEVOLE (id, id_utilisateur, adresse, contact_urgence, notes, actif) SELECT id, id_utilisateur, adresse, contact_urgence, notes, actif FROM __temp__BENEVOLE');
        $this->addSql('DROP TABLE __temp__BENEVOLE');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_7232D39750EAE44 ON BENEVOLE (id_utilisateur)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__COMMUNICATION AS SELECT id, id_evenement, titre, type, date_prevue, statut, budget, notes, date_creation FROM COMMUNICATION');
        $this->addSql('DROP TABLE COMMUNICATION');
        $this->addSql('CREATE TABLE COMMUNICATION (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_evenement INTEGER DEFAULT NULL, titre VARCHAR(255) NOT NULL, type VARCHAR(255) DEFAULT \'post\', date_prevue DATETIME DEFAULT NULL, statut VARCHAR(255) DEFAULT \'brouillon\', budget DOUBLE PRECISION DEFAULT \'0\', notes CLOB DEFAULT NULL, date_creation DATETIME DEFAULT NULL, FOREIGN KEY (id_evenement) REFERENCES EVENEMENT (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO COMMUNICATION (id, id_evenement, titre, type, date_prevue, statut, budget, notes, date_creation) SELECT id, id_evenement, titre, type, date_prevue, statut, budget, notes, date_creation FROM __temp__COMMUNICATION');
        $this->addSql('DROP TABLE __temp__COMMUNICATION');
        $this->addSql('CREATE INDEX IDX_DFE3B70E8B13D439 ON COMMUNICATION (id_evenement)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__CONVENTION AS SELECT id, id_mecene, nom_modele, url_pdf, date_signature, methode_signature, date_creation FROM CONVENTION');
        $this->addSql('DROP TABLE CONVENTION');
        $this->addSql('CREATE TABLE CONVENTION (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_mecene INTEGER NOT NULL, nom_modele VARCHAR(255) DEFAULT NULL, url_pdf VARCHAR(255) DEFAULT NULL, date_signature DATETIME DEFAULT NULL, methode_signature VARCHAR(255) DEFAULT \'aucune\' NOT NULL, date_creation DATETIME DEFAULT NULL, FOREIGN KEY (id_mecene) REFERENCES MECENE (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO CONVENTION (id, id_mecene, nom_modele, url_pdf, date_signature, methode_signature, date_creation) SELECT id, id_mecene, nom_modele, url_pdf, date_signature, methode_signature, date_creation FROM __temp__CONVENTION');
        $this->addSql('DROP TABLE __temp__CONVENTION');
        $this->addSql('CREATE INDEX IDX_8EC97841D364722F ON CONVENTION (id_mecene)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__CRENEAU AS SELECT id, id_evenement, titre, poste_requis, debut, fin, max_personnes, notes, date_creation FROM CRENEAU');
        $this->addSql('DROP TABLE CRENEAU');
        $this->addSql('CREATE TABLE CRENEAU (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_evenement INTEGER NOT NULL, titre VARCHAR(255) NOT NULL, poste_requis VARCHAR(255) DEFAULT NULL, debut DATETIME NOT NULL, fin DATETIME NOT NULL, max_personnes INTEGER NOT NULL, notes CLOB DEFAULT NULL, date_creation DATETIME DEFAULT NULL, FOREIGN KEY (id_evenement) REFERENCES EVENEMENT (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO CRENEAU (id, id_evenement, titre, poste_requis, debut, fin, max_personnes, notes, date_creation) SELECT id, id_evenement, titre, poste_requis, debut, fin, max_personnes, notes, date_creation FROM __temp__CRENEAU');
        $this->addSql('DROP TABLE __temp__CRENEAU');
        $this->addSql('CREATE INDEX IDX_C62375458B13D439 ON CRENEAU (id_evenement)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__DISPONIBILITE_BENEVOLE AS SELECT id, id_benevole, id_evenement, debut, fin, notes, date_creation FROM DISPONIBILITE_BENEVOLE');
        $this->addSql('DROP TABLE DISPONIBILITE_BENEVOLE');
        $this->addSql('CREATE TABLE DISPONIBILITE_BENEVOLE (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_benevole INTEGER NOT NULL, id_evenement INTEGER NOT NULL, debut DATETIME DEFAULT NULL, fin DATETIME DEFAULT NULL, notes CLOB DEFAULT NULL, date_creation DATETIME DEFAULT NULL, FOREIGN KEY (id_benevole) REFERENCES BENEVOLE (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE, FOREIGN KEY (id_evenement) REFERENCES EVENEMENT (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO DISPONIBILITE_BENEVOLE (id, id_benevole, id_evenement, debut, fin, notes, date_creation) SELECT id, id_benevole, id_evenement, debut, fin, notes, date_creation FROM __temp__DISPONIBILITE_BENEVOLE');
        $this->addSql('DROP TABLE __temp__DISPONIBILITE_BENEVOLE');
        $this->addSql('CREATE INDEX IDX_FA2761DCE4DAA34E ON DISPONIBILITE_BENEVOLE (id_benevole)');
        $this->addSql('CREATE INDEX IDX_FA2761DC8B13D439 ON DISPONIBILITE_BENEVOLE (id_evenement)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__EVENEMENT AS SELECT id, nom, description, date_debut, date_fin, lieu, date_creation FROM EVENEMENT');
        $this->addSql('DROP TABLE EVENEMENT');
        $this->addSql('CREATE TABLE EVENEMENT (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, description CLOB DEFAULT NULL, date_debut DATE DEFAULT NULL, date_fin DATE DEFAULT NULL, lieu VARCHAR(255) DEFAULT NULL, date_creation DATETIME DEFAULT NULL)');
        $this->addSql('INSERT INTO EVENEMENT (id, nom, description, date_debut, date_fin, lieu, date_creation) SELECT id, nom, description, date_debut, date_fin, lieu, date_creation FROM __temp__EVENEMENT');
        $this->addSql('DROP TABLE __temp__EVENEMENT');
        $this->addSql('CREATE TEMPORARY TABLE __temp__HELLOASSO AS SELECT id, id_evenement, id_externe, prenom, nom, email, telephone, type_ticket, date_achat, date_import FROM HELLOASSO');
        $this->addSql('DROP TABLE HELLOASSO');
        $this->addSql('CREATE TABLE HELLOASSO (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_evenement INTEGER DEFAULT NULL, id_externe VARCHAR(255) DEFAULT NULL, prenom VARCHAR(255) DEFAULT NULL, nom VARCHAR(255) DEFAULT NULL, email VARCHAR(255) DEFAULT NULL, telephone VARCHAR(255) DEFAULT NULL, type_ticket VARCHAR(255) DEFAULT NULL, date_achat DATETIME DEFAULT NULL, date_import DATETIME DEFAULT NULL, FOREIGN KEY (id_evenement) REFERENCES EVENEMENT (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO HELLOASSO (id, id_evenement, id_externe, prenom, nom, email, telephone, type_ticket, date_achat, date_import) SELECT id, id_evenement, id_externe, prenom, nom, email, telephone, type_ticket, date_achat, date_import FROM __temp__HELLOASSO');
        $this->addSql('DROP TABLE __temp__HELLOASSO');
        $this->addSql('CREATE INDEX IDX_F90B9E9D8B13D439 ON HELLOASSO (id_evenement)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__HISTORIQUE_STOCK AS SELECT id, id_stock, id_evenement, id_utilisateur, type_changement, quantite, raison, date_creation FROM HISTORIQUE_STOCK');
        $this->addSql('DROP TABLE HISTORIQUE_STOCK');
        $this->addSql('CREATE TABLE HISTORIQUE_STOCK (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_stock INTEGER NOT NULL, id_evenement INTEGER DEFAULT NULL, id_utilisateur INTEGER DEFAULT NULL, type_changement VARCHAR(255) NOT NULL, quantite INTEGER NOT NULL, raison CLOB DEFAULT NULL, date_creation DATETIME DEFAULT NULL, FOREIGN KEY (id_stock) REFERENCES STOCK (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE, FOREIGN KEY (id_evenement) REFERENCES EVENEMENT (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE, FOREIGN KEY (id_utilisateur) REFERENCES UTILISATEUR (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO HISTORIQUE_STOCK (id, id_stock, id_evenement, id_utilisateur, type_changement, quantite, raison, date_creation) SELECT id, id_stock, id_evenement, id_utilisateur, type_changement, quantite, raison, date_creation FROM __temp__HISTORIQUE_STOCK');
        $this->addSql('DROP TABLE __temp__HISTORIQUE_STOCK');
        $this->addSql('CREATE INDEX IDX_76C8B6FBA5B31750 ON HISTORIQUE_STOCK (id_stock)');
        $this->addSql('CREATE INDEX IDX_76C8B6FB8B13D439 ON HISTORIQUE_STOCK (id_evenement)');
        $this->addSql('CREATE INDEX IDX_76C8B6FB50EAE44 ON HISTORIQUE_STOCK (id_utilisateur)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__LOT AS SELECT id, id_mecene, titre, description, quantite, valeur_estimee, date_creation FROM LOT');
        $this->addSql('DROP TABLE LOT');
        $this->addSql('CREATE TABLE LOT (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_mecene INTEGER DEFAULT NULL, titre VARCHAR(255) NOT NULL, description CLOB DEFAULT NULL, quantite INTEGER NOT NULL, valeur_estimee DOUBLE PRECISION NOT NULL, date_creation DATETIME DEFAULT NULL, FOREIGN KEY (id_mecene) REFERENCES MECENE (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO LOT (id, id_mecene, titre, description, quantite, valeur_estimee, date_creation) SELECT id, id_mecene, titre, description, quantite, valeur_estimee, date_creation FROM __temp__LOT');
        $this->addSql('DROP TABLE __temp__LOT');
        $this->addSql('CREATE INDEX IDX_9D266B91D364722F ON LOT (id_mecene)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__MECENE AS SELECT id, id_utilisateur, organisation, nom_contact, email_contact, telephone_contact, adresse FROM MECENE');
        $this->addSql('DROP TABLE MECENE');
        $this->addSql('CREATE TABLE MECENE (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_utilisateur INTEGER DEFAULT NULL, organisation VARCHAR(255) DEFAULT NULL, nom_contact VARCHAR(255) DEFAULT NULL, email_contact VARCHAR(255) DEFAULT NULL, telephone_contact VARCHAR(255) DEFAULT NULL, adresse CLOB DEFAULT NULL, FOREIGN KEY (id_utilisateur) REFERENCES UTILISATEUR (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO MECENE (id, id_utilisateur, organisation, nom_contact, email_contact, telephone_contact, adresse) SELECT id, id_utilisateur, organisation, nom_contact, email_contact, telephone_contact, adresse FROM __temp__MECENE');
        $this->addSql('DROP TABLE __temp__MECENE');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_5AB004450EAE44 ON MECENE (id_utilisateur)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__PARAMETRE AS SELECT id, cle, valeur, date_modification FROM PARAMETRE');
        $this->addSql('DROP TABLE PARAMETRE');
        $this->addSql('CREATE TABLE PARAMETRE (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, cle VARCHAR(255) NOT NULL, valeur VARCHAR(255) DEFAULT NULL, date_modification DATETIME DEFAULT NULL)');
        $this->addSql('INSERT INTO PARAMETRE (id, cle, valeur, date_modification) SELECT id, cle, valeur, date_modification FROM __temp__PARAMETRE');
        $this->addSql('DROP TABLE __temp__PARAMETRE');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_E8058EAE41401D17 ON PARAMETRE (cle)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__ROLE AS SELECT id, nom, description FROM ROLE');
        $this->addSql('DROP TABLE ROLE');
        $this->addSql('CREATE TABLE ROLE (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, description CLOB DEFAULT NULL)');
        $this->addSql('INSERT INTO ROLE (id, nom, description) SELECT id, nom, description FROM __temp__ROLE');
        $this->addSql('DROP TABLE __temp__ROLE');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_61FC67DE6C6E55B5 ON ROLE (nom)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__STOCK AS SELECT id, nom, categorie, quantite, unite, seuil, notes, derniere_modif FROM STOCK');
        $this->addSql('DROP TABLE STOCK');
        $this->addSql('CREATE TABLE STOCK (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, categorie VARCHAR(255) DEFAULT NULL, quantite INTEGER NOT NULL, unite VARCHAR(255) DEFAULT NULL, seuil INTEGER NOT NULL, notes CLOB DEFAULT NULL, derniere_modif DATETIME DEFAULT NULL, valeur_unitaire DOUBLE PRECISION DEFAULT \'0\' NOT NULL)');
        $this->addSql('INSERT INTO STOCK (id, nom, categorie, quantite, unite, seuil, notes, derniere_modif) SELECT id, nom, categorie, quantite, unite, seuil, notes, derniere_modif FROM __temp__STOCK');
        $this->addSql('DROP TABLE __temp__STOCK');
        $this->addSql('CREATE TEMPORARY TABLE __temp__UTILISATEUR AS SELECT id, id_role, email, mot_de_passe, prenom, nom, telephone, date_creation, date_modification FROM UTILISATEUR');
        $this->addSql('DROP TABLE UTILISATEUR');
        $this->addSql('CREATE TABLE UTILISATEUR (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_role INTEGER NOT NULL, email VARCHAR(180) NOT NULL, mot_de_passe VARCHAR(255) DEFAULT NULL, prenom VARCHAR(255) DEFAULT NULL, nom VARCHAR(255) DEFAULT NULL, telephone VARCHAR(255) DEFAULT NULL, date_creation DATETIME DEFAULT NULL, date_modification DATETIME DEFAULT NULL, FOREIGN KEY (id_role) REFERENCES ROLE (id) ON UPDATE NO ACTION ON DELETE NO ACTION NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO UTILISATEUR (id, id_role, email, mot_de_passe, prenom, nom, telephone, date_creation, date_modification) SELECT id, id_role, email, mot_de_passe, prenom, nom, telephone, date_creation, date_modification FROM __temp__UTILISATEUR');
        $this->addSql('DROP TABLE __temp__UTILISATEUR');
        $this->addSql('CREATE INDEX IDX_901FF15BDC499668 ON UTILISATEUR (id_role)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_901FF15BE7927C74 ON UTILISATEUR (email)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE messenger_messages');
        $this->addSql('CREATE TEMPORARY TABLE __temp__AFFECTATION_CRENEAU AS SELECT id, id_creneau, id_benevole, id_utilisateur, date_affectation, statut, notes FROM AFFECTATION_CRENEAU');
        $this->addSql('DROP TABLE AFFECTATION_CRENEAU');
        $this->addSql('CREATE TABLE AFFECTATION_CRENEAU (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, id_creneau INTEGER NOT NULL, id_benevole INTEGER NOT NULL, id_utilisateur INTEGER DEFAULT NULL, date_affectation DATETIME DEFAULT CURRENT_TIMESTAMP, statut CLOB DEFAULT \'assigne\', notes CLOB DEFAULT NULL, CONSTRAINT FK_E3AC04B627FB222F FOREIGN KEY (id_creneau) REFERENCES CRENEAU (id) NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_E3AC04B6E4DAA34E FOREIGN KEY (id_benevole) REFERENCES BENEVOLE (id) NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_E3AC04B650EAE44 FOREIGN KEY (id_utilisateur) REFERENCES UTILISATEUR (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO AFFECTATION_CRENEAU (id, id_creneau, id_benevole, id_utilisateur, date_affectation, statut, notes) SELECT id, id_creneau, id_benevole, id_utilisateur, date_affectation, statut, notes FROM __temp__AFFECTATION_CRENEAU');
        $this->addSql('DROP TABLE __temp__AFFECTATION_CRENEAU');
        $this->addSql('CREATE INDEX IDX_E3AC04B627FB222F ON AFFECTATION_CRENEAU (id_creneau)');
        $this->addSql('CREATE INDEX IDX_E3AC04B6E4DAA34E ON AFFECTATION_CRENEAU (id_benevole)');
        $this->addSql('CREATE INDEX IDX_E3AC04B650EAE44 ON AFFECTATION_CRENEAU (id_utilisateur)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__BENEVOLE AS SELECT id, id_utilisateur, adresse, contact_urgence, notes, actif FROM BENEVOLE');
        $this->addSql('DROP TABLE BENEVOLE');
        $this->addSql('CREATE TABLE BENEVOLE (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, id_utilisateur INTEGER NOT NULL, adresse CLOB DEFAULT NULL, contact_urgence CLOB DEFAULT NULL, notes CLOB DEFAULT NULL, actif BOOLEAN DEFAULT 1, CONSTRAINT FK_7232D39750EAE44 FOREIGN KEY (id_utilisateur) REFERENCES UTILISATEUR (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO BENEVOLE (id, id_utilisateur, adresse, contact_urgence, notes, actif) SELECT id, id_utilisateur, adresse, contact_urgence, notes, actif FROM __temp__BENEVOLE');
        $this->addSql('DROP TABLE __temp__BENEVOLE');
        $this->addSql('CREATE INDEX IDX_7232D39750EAE44 ON BENEVOLE (id_utilisateur)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__COMMUNICATION AS SELECT id, id_evenement, titre, type, date_prevue, statut, budget, notes, date_creation FROM COMMUNICATION');
        $this->addSql('DROP TABLE COMMUNICATION');
        $this->addSql('CREATE TABLE COMMUNICATION (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, id_evenement INTEGER DEFAULT NULL, titre CLOB NOT NULL, type CLOB DEFAULT \'post\', date_prevue DATETIME DEFAULT NULL, statut CLOB DEFAULT \'brouillon\', budget DOUBLE PRECISION DEFAULT \'0.0\', notes CLOB DEFAULT NULL, date_creation DATETIME DEFAULT CURRENT_TIMESTAMP, CONSTRAINT FK_DFE3B70E8B13D439 FOREIGN KEY (id_evenement) REFERENCES EVENEMENT (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO COMMUNICATION (id, id_evenement, titre, type, date_prevue, statut, budget, notes, date_creation) SELECT id, id_evenement, titre, type, date_prevue, statut, budget, notes, date_creation FROM __temp__COMMUNICATION');
        $this->addSql('DROP TABLE __temp__COMMUNICATION');
        $this->addSql('CREATE INDEX IDX_DFE3B70E8B13D439 ON COMMUNICATION (id_evenement)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__CONVENTION AS SELECT id, id_mecene, nom_modele, url_pdf, date_signature, methode_signature, date_creation FROM CONVENTION');
        $this->addSql('DROP TABLE CONVENTION');
        $this->addSql('CREATE TABLE CONVENTION (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, id_mecene INTEGER NOT NULL, nom_modele CLOB DEFAULT NULL, url_pdf CLOB DEFAULT NULL, date_signature DATETIME DEFAULT NULL, methode_signature CLOB DEFAULT \'aucune\', date_creation DATETIME DEFAULT CURRENT_TIMESTAMP, CONSTRAINT FK_8EC97841D364722F FOREIGN KEY (id_mecene) REFERENCES MECENE (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO CONVENTION (id, id_mecene, nom_modele, url_pdf, date_signature, methode_signature, date_creation) SELECT id, id_mecene, nom_modele, url_pdf, date_signature, methode_signature, date_creation FROM __temp__CONVENTION');
        $this->addSql('DROP TABLE __temp__CONVENTION');
        $this->addSql('CREATE INDEX IDX_8EC97841D364722F ON CONVENTION (id_mecene)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__CRENEAU AS SELECT id, id_evenement, titre, poste_requis, debut, fin, max_personnes, notes, date_creation FROM CRENEAU');
        $this->addSql('DROP TABLE CRENEAU');
        $this->addSql('CREATE TABLE CRENEAU (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, id_evenement INTEGER NOT NULL, titre CLOB NOT NULL, poste_requis CLOB DEFAULT NULL, debut DATETIME NOT NULL, fin DATETIME NOT NULL, max_personnes INTEGER DEFAULT 1, notes CLOB DEFAULT NULL, date_creation DATETIME DEFAULT CURRENT_TIMESTAMP, CONSTRAINT FK_C62375458B13D439 FOREIGN KEY (id_evenement) REFERENCES EVENEMENT (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO CRENEAU (id, id_evenement, titre, poste_requis, debut, fin, max_personnes, notes, date_creation) SELECT id, id_evenement, titre, poste_requis, debut, fin, max_personnes, notes, date_creation FROM __temp__CRENEAU');
        $this->addSql('DROP TABLE __temp__CRENEAU');
        $this->addSql('CREATE INDEX IDX_C62375458B13D439 ON CRENEAU (id_evenement)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__DISPONIBILITE_BENEVOLE AS SELECT id, id_benevole, id_evenement, debut, fin, notes, date_creation FROM DISPONIBILITE_BENEVOLE');
        $this->addSql('DROP TABLE DISPONIBILITE_BENEVOLE');
        $this->addSql('CREATE TABLE DISPONIBILITE_BENEVOLE (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, id_benevole INTEGER NOT NULL, id_evenement INTEGER NOT NULL, debut DATETIME DEFAULT NULL, fin DATETIME DEFAULT NULL, notes CLOB DEFAULT NULL, date_creation DATETIME DEFAULT CURRENT_TIMESTAMP, CONSTRAINT FK_FA2761DCE4DAA34E FOREIGN KEY (id_benevole) REFERENCES BENEVOLE (id) NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_FA2761DC8B13D439 FOREIGN KEY (id_evenement) REFERENCES EVENEMENT (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO DISPONIBILITE_BENEVOLE (id, id_benevole, id_evenement, debut, fin, notes, date_creation) SELECT id, id_benevole, id_evenement, debut, fin, notes, date_creation FROM __temp__DISPONIBILITE_BENEVOLE');
        $this->addSql('DROP TABLE __temp__DISPONIBILITE_BENEVOLE');
        $this->addSql('CREATE INDEX IDX_FA2761DCE4DAA34E ON DISPONIBILITE_BENEVOLE (id_benevole)');
        $this->addSql('CREATE INDEX IDX_FA2761DC8B13D439 ON DISPONIBILITE_BENEVOLE (id_evenement)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__EVENEMENT AS SELECT id, nom, description, date_debut, date_fin, lieu, date_creation FROM EVENEMENT');
        $this->addSql('DROP TABLE EVENEMENT');
        $this->addSql('CREATE TABLE EVENEMENT (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, nom CLOB NOT NULL, description CLOB DEFAULT NULL, date_debut DATE DEFAULT NULL, date_fin DATE DEFAULT NULL, lieu CLOB DEFAULT NULL, date_creation DATETIME DEFAULT CURRENT_TIMESTAMP)');
        $this->addSql('INSERT INTO EVENEMENT (id, nom, description, date_debut, date_fin, lieu, date_creation) SELECT id, nom, description, date_debut, date_fin, lieu, date_creation FROM __temp__EVENEMENT');
        $this->addSql('DROP TABLE __temp__EVENEMENT');
        $this->addSql('CREATE TEMPORARY TABLE __temp__HELLOASSO AS SELECT id, id_evenement, id_externe, prenom, nom, email, telephone, type_ticket, date_achat, date_import FROM HELLOASSO');
        $this->addSql('DROP TABLE HELLOASSO');
        $this->addSql('CREATE TABLE HELLOASSO (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, id_evenement INTEGER DEFAULT NULL, id_externe CLOB DEFAULT NULL, prenom CLOB DEFAULT NULL, nom CLOB DEFAULT NULL, email CLOB DEFAULT NULL, telephone CLOB DEFAULT NULL, type_ticket CLOB DEFAULT NULL, date_achat DATETIME DEFAULT NULL, date_import DATETIME DEFAULT CURRENT_TIMESTAMP, CONSTRAINT FK_F90B9E9D8B13D439 FOREIGN KEY (id_evenement) REFERENCES EVENEMENT (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO HELLOASSO (id, id_evenement, id_externe, prenom, nom, email, telephone, type_ticket, date_achat, date_import) SELECT id, id_evenement, id_externe, prenom, nom, email, telephone, type_ticket, date_achat, date_import FROM __temp__HELLOASSO');
        $this->addSql('DROP TABLE __temp__HELLOASSO');
        $this->addSql('CREATE INDEX IDX_F90B9E9D8B13D439 ON HELLOASSO (id_evenement)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__HISTORIQUE_STOCK AS SELECT id, id_stock, id_evenement, id_utilisateur, type_changement, quantite, raison, date_creation FROM HISTORIQUE_STOCK');
        $this->addSql('DROP TABLE HISTORIQUE_STOCK');
        $this->addSql('CREATE TABLE HISTORIQUE_STOCK (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, id_stock INTEGER NOT NULL, id_evenement INTEGER DEFAULT NULL, id_utilisateur INTEGER DEFAULT NULL, type_changement CLOB NOT NULL, quantite INTEGER NOT NULL, raison CLOB DEFAULT NULL, date_creation DATETIME DEFAULT CURRENT_TIMESTAMP, CONSTRAINT FK_76C8B6FBA5B31750 FOREIGN KEY (id_stock) REFERENCES STOCK (id) NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_76C8B6FB8B13D439 FOREIGN KEY (id_evenement) REFERENCES EVENEMENT (id) NOT DEFERRABLE INITIALLY IMMEDIATE, CONSTRAINT FK_76C8B6FB50EAE44 FOREIGN KEY (id_utilisateur) REFERENCES UTILISATEUR (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO HISTORIQUE_STOCK (id, id_stock, id_evenement, id_utilisateur, type_changement, quantite, raison, date_creation) SELECT id, id_stock, id_evenement, id_utilisateur, type_changement, quantite, raison, date_creation FROM __temp__HISTORIQUE_STOCK');
        $this->addSql('DROP TABLE __temp__HISTORIQUE_STOCK');
        $this->addSql('CREATE INDEX IDX_76C8B6FBA5B31750 ON HISTORIQUE_STOCK (id_stock)');
        $this->addSql('CREATE INDEX IDX_76C8B6FB8B13D439 ON HISTORIQUE_STOCK (id_evenement)');
        $this->addSql('CREATE INDEX IDX_76C8B6FB50EAE44 ON HISTORIQUE_STOCK (id_utilisateur)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__LOT AS SELECT id, id_mecene, titre, description, quantite, valeur_estimee, date_creation FROM LOT');
        $this->addSql('DROP TABLE LOT');
        $this->addSql('CREATE TABLE LOT (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, id_mecene INTEGER DEFAULT NULL, titre CLOB NOT NULL, description CLOB DEFAULT NULL, quantite INTEGER DEFAULT 1, valeur_estimee DOUBLE PRECISION DEFAULT \'0.0\', date_creation DATETIME DEFAULT CURRENT_TIMESTAMP, CONSTRAINT FK_9D266B91D364722F FOREIGN KEY (id_mecene) REFERENCES MECENE (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO LOT (id, id_mecene, titre, description, quantite, valeur_estimee, date_creation) SELECT id, id_mecene, titre, description, quantite, valeur_estimee, date_creation FROM __temp__LOT');
        $this->addSql('DROP TABLE __temp__LOT');
        $this->addSql('CREATE INDEX IDX_9D266B91D364722F ON LOT (id_mecene)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__MECENE AS SELECT id, id_utilisateur, organisation, nom_contact, email_contact, telephone_contact, adresse FROM MECENE');
        $this->addSql('DROP TABLE MECENE');
        $this->addSql('CREATE TABLE MECENE (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, id_utilisateur INTEGER DEFAULT NULL, organisation CLOB DEFAULT NULL, nom_contact CLOB DEFAULT NULL, email_contact CLOB DEFAULT NULL, telephone_contact CLOB DEFAULT NULL, adresse CLOB DEFAULT NULL, CONSTRAINT FK_5AB004450EAE44 FOREIGN KEY (id_utilisateur) REFERENCES UTILISATEUR (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO MECENE (id, id_utilisateur, organisation, nom_contact, email_contact, telephone_contact, adresse) SELECT id, id_utilisateur, organisation, nom_contact, email_contact, telephone_contact, adresse FROM __temp__MECENE');
        $this->addSql('DROP TABLE __temp__MECENE');
        $this->addSql('CREATE INDEX IDX_5AB004450EAE44 ON MECENE (id_utilisateur)');
        $this->addSql('CREATE TEMPORARY TABLE __temp__PARAMETRE AS SELECT id, cle, valeur, date_modification FROM PARAMETRE');
        $this->addSql('DROP TABLE PARAMETRE');
        $this->addSql('CREATE TABLE PARAMETRE (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, cle CLOB NOT NULL, valeur CLOB DEFAULT NULL, date_modification DATETIME DEFAULT CURRENT_TIMESTAMP)');
        $this->addSql('INSERT INTO PARAMETRE (id, cle, valeur, date_modification) SELECT id, cle, valeur, date_modification FROM __temp__PARAMETRE');
        $this->addSql('DROP TABLE __temp__PARAMETRE');
        $this->addSql('CREATE TEMPORARY TABLE __temp__ROLE AS SELECT id, nom, description FROM ROLE');
        $this->addSql('DROP TABLE ROLE');
        $this->addSql('CREATE TABLE ROLE (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, nom CLOB NOT NULL, description CLOB DEFAULT NULL)');
        $this->addSql('INSERT INTO ROLE (id, nom, description) SELECT id, nom, description FROM __temp__ROLE');
        $this->addSql('DROP TABLE __temp__ROLE');
        $this->addSql('CREATE TEMPORARY TABLE __temp__STOCK AS SELECT id, nom, categorie, quantite, unite, seuil, notes, derniere_modif FROM STOCK');
        $this->addSql('DROP TABLE STOCK');
        $this->addSql('CREATE TABLE STOCK (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, nom CLOB NOT NULL, categorie CLOB DEFAULT NULL, quantite INTEGER DEFAULT 0, unite CLOB DEFAULT NULL, seuil INTEGER DEFAULT 0, notes CLOB DEFAULT NULL, derniere_modif DATETIME DEFAULT CURRENT_TIMESTAMP)');
        $this->addSql('INSERT INTO STOCK (id, nom, categorie, quantite, unite, seuil, notes, derniere_modif) SELECT id, nom, categorie, quantite, unite, seuil, notes, derniere_modif FROM __temp__STOCK');
        $this->addSql('DROP TABLE __temp__STOCK');
        $this->addSql('CREATE TEMPORARY TABLE __temp__UTILISATEUR AS SELECT id, id_role, email, mot_de_passe, prenom, nom, telephone, date_creation, date_modification FROM UTILISATEUR');
        $this->addSql('DROP TABLE UTILISATEUR');
        $this->addSql('CREATE TABLE UTILISATEUR (id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT NULL, id_role INTEGER NOT NULL, email CLOB NOT NULL, mot_de_passe CLOB DEFAULT NULL, prenom CLOB DEFAULT NULL, nom CLOB DEFAULT NULL, telephone CLOB DEFAULT NULL, date_creation DATETIME DEFAULT CURRENT_TIMESTAMP, date_modification DATETIME DEFAULT CURRENT_TIMESTAMP, CONSTRAINT FK_901FF15BDC499668 FOREIGN KEY (id_role) REFERENCES ROLE (id) NOT DEFERRABLE INITIALLY IMMEDIATE)');
        $this->addSql('INSERT INTO UTILISATEUR (id, id_role, email, mot_de_passe, prenom, nom, telephone, date_creation, date_modification) SELECT id, id_role, email, mot_de_passe, prenom, nom, telephone, date_creation, date_modification FROM __temp__UTILISATEUR');
        $this->addSql('DROP TABLE __temp__UTILISATEUR');
        $this->addSql('CREATE INDEX IDX_901FF15BDC499668 ON UTILISATEUR (id_role)');
    }
}
